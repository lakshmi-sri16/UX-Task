# Overview

RecruitCRM is a full-stack web application designed for recruitment and customer relationship management. The application serves as a comprehensive platform for managing companies, contacts, job postings, candidates, and recruitment activities. Built with modern web technologies, it provides a clean, professional interface for tracking and managing the entire recruitment pipeline.

The system allows users to maintain detailed company profiles, manage contact relationships, track job openings, monitor candidate progress through various stages, and record recruitment activities. The application features a tabbed interface for organizing different aspects of company management and provides comprehensive CRUD operations for all entities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript for type safety and modern component development
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and caching
- **UI Framework**: Radix UI components with shadcn/ui for accessible, customizable component library
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
- **Runtime**: Node.js with Express.js framework for REST API development
- **Language**: TypeScript for type safety across the full stack
- **API Design**: RESTful architecture with resource-based endpoints
- **Data Validation**: Zod schemas for runtime type checking and validation
- **Development**: Hot module reloading with Vite integration for seamless development experience

## Data Storage Solutions
- **Database**: PostgreSQL for relational data storage
- **ORM**: Drizzle ORM with PostgreSQL dialect for type-safe database operations
- **Schema Management**: Drizzle Kit for database migrations and schema management
- **Connection**: Neon Database serverless PostgreSQL for cloud hosting
- **In-Memory Storage**: MemStorage class for development and testing with sample data initialization

## Database Schema Design
- **Companies**: Core entity with business information, industry, location, and status tracking
- **Contacts**: Person records linked to companies with role and communication details
- **Jobs**: Job postings associated with companies including requirements and application tracking
- **Candidates**: Applicant records with stage tracking and company/job associations
- **Activities**: Activity log for tracking interactions and events across the recruitment process
- **Relationships**: Foreign key constraints ensuring data integrity between related entities

## Authentication and Authorization
- **Session Management**: Connect-pg-simple for PostgreSQL-backed session storage
- **Security**: Express session middleware for user authentication state
- **API Protection**: Middleware-based request validation and error handling

## UI/UX Design Patterns
- **Component Structure**: Shared component library with consistent design patterns
- **Theme System**: CSS custom properties for light/dark mode support
- **Responsive Design**: Mobile-first approach with Tailwind breakpoints
- **Accessibility**: Radix UI primitives ensuring ARIA compliance and keyboard navigation
- **Loading States**: Skeleton components and loading indicators for better user experience

## Error Handling and Logging
- **API Errors**: Centralized error handling middleware with proper HTTP status codes
- **Request Logging**: Custom middleware for API request/response logging with performance metrics
- **Validation**: Zod schema validation with detailed error messages
- **Development Tools**: Runtime error overlay for development debugging

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting for production database
- **Drizzle ORM**: Type-safe database toolkit for PostgreSQL operations

## UI Component Libraries
- **Radix UI**: Headless component primitives for accessibility and customization
- **Lucide React**: Icon library for consistent iconography
- **Embla Carousel**: Carousel component for image galleries

## Development Tools
- **Replit Integration**: Custom Vite plugins for Replit development environment
- **PostCSS**: CSS processing with Tailwind CSS and Autoprefixer

## Utility Libraries
- **Date-fns**: Date manipulation and formatting
- **Class Variance Authority**: Utility for managing conditional CSS classes
- **CLSX**: Conditional className utility
- **Nanoid**: Unique ID generation for entities

## Build and Development
- **Vite**: Build tool and development server
- **ESBuild**: Fast bundling for production builds
- **TypeScript**: Static type checking across the application
- **React Hook Form**: Form state management with validation

## Query and State Management
- **TanStack Query**: Server state management, caching, and synchronization
- **React Router**: Client-side routing with Wouter library