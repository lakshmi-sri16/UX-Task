import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { type Company } from "@shared/schema";
import Header from "@/components/header";
import CompanyHeader from "@/components/company-header";
import OverviewTab from "@/components/tabs/overview-tab";
import ContactsTab from "@/components/tabs/contacts-tab.tsx";
import JobsTab from "@/components/tabs/jobs-tab.tsx";
import CandidatesTab from "@/components/tabs/candidates-tab.tsx";
import ActivitiesTab from "@/components/tabs/activities-tab.tsx";
import { Card } from "@/components/ui/card";

const tabs = [
  { id: "overview", label: "Overview" },
  { id: "contacts", label: "Contacts" },
  { id: "jobs", label: "Jobs" },
  { id: "candidates", label: "Candidates" },
  { id: "activities", label: "Activities" },
];

export default function CompanyProfile() {
  const { id } = useParams();
  const [activeTab, setActiveTab] = useState("overview");
  
  // For demo purposes, use the first company if no ID is provided
  const companyId = id || "default";

  const { data: companies, isLoading: companiesLoading } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const company = companies?.[0]; // Use first company for demo

  if (companiesLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="animate-pulse space-y-6">
            <div className="h-48 bg-muted rounded-lg"></div>
            <div className="h-96 bg-muted rounded-lg"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!company) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <Card className="p-6 text-center">
            <h2 className="text-xl font-semibold text-foreground mb-2">
              Company Not Found
            </h2>
            <p className="text-muted-foreground">
              The requested company could not be found.
            </p>
          </Card>
        </div>
      </div>
    );
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case "overview":
        return <OverviewTab company={company} />;
      case "contacts":
        return <ContactsTab companyId={company.id} />;
      case "jobs":
        return <JobsTab companyId={company.id} />;
      case "candidates":
        return <CandidatesTab companyId={company.id} />;
      case "activities":
        return <ActivitiesTab companyId={company.id} />;
      default:
        return <OverviewTab company={company} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <CompanyHeader company={company} />
        
        <Card className="shadow-sm">
          <div className="border-b border-border">
            <nav className="flex space-x-8 px-6" aria-label="Tabs">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm transition-colors ${
                    activeTab === tab.id
                      ? "border-primary text-primary bg-accent"
                      : "border-transparent text-muted-foreground hover:text-foreground hover:border-border"
                  }`}
                  data-testid={`tab-${tab.id}`}
                >
                  {tab.label}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {renderTabContent()}
          </div>
        </Card>
      </div>
    </div>
  );
}
