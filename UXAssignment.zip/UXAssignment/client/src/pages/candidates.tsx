import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Plus, Eye, Calendar, Mail } from "lucide-react";
import { type Candidate, type Company } from "@shared/schema";
import Header from "@/components/header";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

export default function Candidates() {
  const [searchTerm, setSearchTerm] = useState("");
  const [stageFilter, setStageFilter] = useState("all");

  const { data: companies } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  // Get all candidates from all companies
  const candidatesQueries = companies?.map(company => 
    useQuery<Candidate[]>({
      queryKey: ["/api/companies", company.id, "candidates"],
      enabled: !!company.id,
    })
  ) || [];

  const allCandidates = candidatesQueries
    .flatMap(query => query.data || [])
    .filter(Boolean);

  const getStageBadge = (stage: string) => {
    switch (stage.toLowerCase()) {
      case "applied":
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100">Applied</Badge>;
      case "screening":
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Screening</Badge>;
      case "interview":
        return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100">Interview</Badge>;
      case "offer":
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Offer</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Rejected</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800 hover:bg-gray-100">{stage}</Badge>;
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const getInitialsColor = (name: string) => {
    const colors = [
      "bg-purple-500",
      "bg-orange-500",
      "bg-blue-500",
      "bg-green-500",
      "bg-red-500",
      "bg-indigo-500",
    ];
    const index = name.charCodeAt(0) % colors.length;
    return colors[index];
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    return `${Math.floor(diffDays / 7)} week${Math.floor(diffDays / 7) > 1 ? "s" : ""} ago`;
  };

  const getCompanyName = (companyId: string) => {
    return companies?.find(c => c.id === companyId)?.name || "Unknown Company";
  };

  const filteredCandidates = allCandidates.filter((candidate) => {
    const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         candidate.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStage = stageFilter === "all" || 
                        candidate.stage.toLowerCase() === stageFilter.toLowerCase();
    return matchesSearch && matchesStage;
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground">Candidates</h1>
          <p className="text-muted-foreground mt-2">Manage all candidates across your recruitment pipeline</p>
        </div>

        <Card className="shadow-sm">
          <div className="p-6 border-b border-border">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
                  <Input
                    type="text"
                    placeholder="Search candidates..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-80"
                    data-testid="input-search-candidates"
                  />
                </div>
                <Select value={stageFilter} onValueChange={setStageFilter}>
                  <SelectTrigger className="w-48" data-testid="select-stage-filter">
                    <SelectValue placeholder="All Stages" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Stages</SelectItem>
                    <SelectItem value="applied">Applied</SelectItem>
                    <SelectItem value="screening">Screening</SelectItem>
                    <SelectItem value="interview">Interview</SelectItem>
                    <SelectItem value="offer">Offer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button className="bg-primary text-primary-foreground hover:bg-primary/90" data-testid="button-add-candidate">
                <Plus className="w-4 h-4 mr-2" />
                Add Candidate
              </Button>
            </div>
          </div>

          <div className="overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted/50 border-b border-border">
                <tr>
                  <th className="text-left py-3 px-6 font-medium text-muted-foreground text-sm">Candidate</th>
                  <th className="text-left py-3 px-6 font-medium text-muted-foreground text-sm">Company</th>
                  <th className="text-left py-3 px-6 font-medium text-muted-foreground text-sm">Stage</th>
                  <th className="text-left py-3 px-6 font-medium text-muted-foreground text-sm">Applied</th>
                  <th className="text-left py-3 px-6 font-medium text-muted-foreground text-sm">Last Update</th>
                  <th className="text-left py-3 px-6 font-medium text-muted-foreground text-sm">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filteredCandidates.length > 0 ? (
                  filteredCandidates.map((candidate) => (
                    <tr key={candidate.id} className="hover:bg-muted/30 transition-colors" data-testid={`row-candidate-${candidate.id}`}>
                      <td className="py-4 px-6">
                        <div className="flex items-center space-x-3">
                          <div className={`w-10 h-10 ${getInitialsColor(candidate.name)} rounded-full flex items-center justify-center`}>
                            <span className="text-white text-sm font-medium">
                              {getInitials(candidate.name)}
                            </span>
                          </div>
                          <div>
                            <div className="font-medium text-foreground">{candidate.name}</div>
                            <div className="text-sm text-muted-foreground">{candidate.email}</div>
                          </div>
                        </div>
                      </td>
                      <td className="py-4 px-6 text-foreground">
                        {getCompanyName(candidate.companyId)}
                      </td>
                      <td className="py-4 px-6">
                        {getStageBadge(candidate.stage)}
                      </td>
                      <td className="py-4 px-6 text-muted-foreground">
                        {formatTimeAgo(candidate.appliedAt!)}
                      </td>
                      <td className="py-4 px-6 text-muted-foreground">
                        {formatTimeAgo(candidate.lastUpdate!)}
                      </td>
                      <td className="py-4 px-6">
                        <div className="flex items-center space-x-2">
                          <Button variant="ghost" size="sm" data-testid={`button-view-${candidate.id}`}>
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" data-testid={`button-schedule-${candidate.id}`}>
                            <Calendar className="w-4 h-4" />
                          </Button>
                          <Button variant="ghost" size="sm" data-testid={`button-email-${candidate.id}`}>
                            <Mail className="w-4 h-4" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-muted-foreground">
                      {searchTerm || stageFilter !== "all" 
                        ? "No candidates match your search criteria" 
                        : "No candidates found"
                      }
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}