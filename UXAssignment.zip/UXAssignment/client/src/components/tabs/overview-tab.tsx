import { useQuery } from "@tanstack/react-query";
import { Phone, Plus, Calendar, Mail, User } from "lucide-react";
import { type Company, type Activity, type Contact } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import JobFormDialog from "@/components/job-form-dialog";

interface OverviewTabProps {
  company: Company;
}

export default function OverviewTab({ company }: OverviewTabProps) {
  const { data: activities } = useQuery<Activity[]>({
    queryKey: ["/api/companies", company.id, "activities"],
  });

  const { data: contacts } = useQuery<Contact[]>({
    queryKey: ["/api/companies", company.id, "contacts"],
  });

  const recentActivities = activities?.slice(0, 5) || [];
  const keyContacts = contacts?.slice(0, 2) || [];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "call":
        return <Phone className="text-blue-600" size={12} />;
      case "job":
        return <Plus className="text-green-600" size={12} />;
      case "email":
        return <Mail className="text-purple-600" size={12} />;
      default:
        return <User className="text-gray-600" size={12} />;
    }
  };

  const getActivityIconBg = (type: string) => {
    switch (type) {
      case "call":
        return "bg-blue-100";
      case "job":
        return "bg-green-100";
      case "email":
        return "bg-purple-100";
      default:
        return "bg-gray-100";
    }
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);

    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
    return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        {/* Company Details */}
        <div className="bg-muted/30 rounded-lg p-4">
          <h3 className="font-semibold text-foreground mb-3">Company Details</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            {company.website && (
              <div>
                <span className="text-muted-foreground">Website:</span>
                <span className="ml-2 text-foreground">{company.website}</span>
              </div>
            )}
            {company.founded && (
              <div>
                <span className="text-muted-foreground">Founded:</span>
                <span className="ml-2 text-foreground">{company.founded}</span>
              </div>
            )}
            {company.revenue && (
              <div>
                <span className="text-muted-foreground">Revenue:</span>
                <span className="ml-2 text-foreground">{company.revenue}</span>
              </div>
            )}
            <div>
              <span className="text-muted-foreground">Status:</span>
              <Badge className="ml-2 bg-green-100 text-green-800 hover:bg-green-100">
                {company.status}
              </Badge>
            </div>
          </div>
          {company.description && (
            <div className="mt-4">
              <span className="text-muted-foreground text-sm">Description:</span>
              <p className="mt-1 text-foreground text-sm">{company.description}</p>
            </div>
          )}
        </div>

        {/* Recent Activity */}
        <div className="bg-muted/30 rounded-lg p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-foreground">Recent Activity</h3>
            <Button variant="link" className="text-primary text-sm p-0 h-auto" data-testid="button-view-all-activities">
              View All
            </Button>
          </div>
          <div className="space-y-3">
            {recentActivities.length > 0 ? (
              recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className={`w-8 h-8 ${getActivityIconBg(activity.type)} rounded-full flex items-center justify-center flex-shrink-0`}>
                    {getActivityIcon(activity.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground">
                      <span className="font-medium">{activity.userName}</span> {activity.title.toLowerCase()}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatTimeAgo(activity.createdAt!)}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No recent activities</p>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions Sidebar */}
      <div className="space-y-4">
        <div className="bg-muted/30 rounded-lg p-4">
          <h3 className="font-semibold text-foreground mb-3">Quick Actions</h3>
          <div className="space-y-2">
            <Button variant="ghost" className="w-full justify-start text-sm" data-testid="button-add-contact">
              <Plus className="w-4 mr-2 text-muted-foreground" />
              Add Contact
            </Button>
            <JobFormDialog 
              companyId={company.id}
              trigger={
                <Button variant="ghost" className="w-full justify-start text-sm" data-testid="button-create-job">
                  <Plus className="w-4 mr-2 text-muted-foreground" />
                  Create Job
                </Button>
              }
            />
            <Button variant="ghost" className="w-full justify-start text-sm" data-testid="button-schedule-meeting">
              <Calendar className="w-4 mr-2 text-muted-foreground" />
              Schedule Meeting
            </Button>
            <Button variant="ghost" className="w-full justify-start text-sm" data-testid="button-send-email">
              <Mail className="w-4 mr-2 text-muted-foreground" />
              Send Email
            </Button>
          </div>
        </div>

        {/* Key Contacts */}
        <div className="bg-muted/30 rounded-lg p-4">
          <h3 className="font-semibold text-foreground mb-3">Key Contacts</h3>
          <div className="space-y-3">
            {keyContacts.length > 0 ? (
              keyContacts.map((contact) => (
                <div key={contact.id} className="flex items-center space-x-3">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <span className="text-primary-foreground text-xs font-medium">
                      {getInitials(contact.name)}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">{contact.name}</p>
                    <p className="text-xs text-muted-foreground">{contact.role || "No role specified"}</p>
                  </div>
                  <Button variant="ghost" size="sm" data-testid={`button-call-${contact.id}`}>
                    <Phone className="w-3 h-3" />
                  </Button>
                </div>
              ))
            ) : (
              <p className="text-sm text-muted-foreground">No contacts available</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
