import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Plus, Phone, Mail, Edit } from "lucide-react";
import { type Contact } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ContactsTabProps {
  companyId: string;
}

export default function ContactsTab({ companyId }: ContactsTabProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");

  const { data: contacts, isLoading } = useQuery<Contact[]>({
    queryKey: ["/api/companies", companyId, "contacts"],
  });

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
  };

  const getInitialsColor = (name: string) => {
    const colors = [
      "bg-primary",
      "bg-green-500",
      "bg-blue-500",
      "bg-purple-500",
      "bg-orange-500",
      "bg-red-500",
    ];
    const index = name.charCodeAt(0) % colors.length;
    return colors[index];
  };

  const formatTimeAgo = (date: Date | null) => {
    if (!date) return "Never";
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} week${Math.floor(diffDays / 7) > 1 ? "s" : ""} ago`;
    return `${Math.floor(diffDays / 30)} month${Math.floor(diffDays / 30) > 1 ? "s" : ""} ago`;
  };

  const filteredContacts = contacts?.filter((contact) => {
    const matchesSearch = contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         contact.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === "all" || 
                       (contact.role && contact.role.toLowerCase().includes(roleFilter.toLowerCase()));
    return matchesSearch && matchesRole;
  }) || [];

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse">
          <div className="h-10 bg-muted rounded-lg mb-4"></div>
          <div className="h-64 bg-muted rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
            <Input
              type="text"
              placeholder="Search contacts..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-80"
              data-testid="input-search-contacts"
            />
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-48" data-testid="select-role-filter">
              <SelectValue placeholder="All Roles" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="hr">HR</SelectItem>
              <SelectItem value="engineering">Engineering</SelectItem>
              <SelectItem value="management">Management</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90" data-testid="button-add-contact">
          <Plus className="w-4 h-4 mr-2" />
          Add Contact
        </Button>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-muted/50 border-b border-border">
            <tr>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">Name</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">Role</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">Email</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">Phone</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">Last Contact</th>
              <th className="text-left py-3 px-4 font-medium text-muted-foreground text-sm">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filteredContacts.length > 0 ? (
              filteredContacts.map((contact) => (
                <tr key={contact.id} className="hover:bg-muted/30 transition-colors" data-testid={`row-contact-${contact.id}`}>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-3">
                      <div className={`w-8 h-8 ${getInitialsColor(contact.name)} rounded-full flex items-center justify-center`}>
                        <span className="text-white text-xs font-medium">
                          {getInitials(contact.name)}
                        </span>
                      </div>
                      <span className="font-medium text-foreground">{contact.name}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-foreground">{contact.role || "-"}</td>
                  <td className="py-3 px-4 text-muted-foreground">{contact.email || "-"}</td>
                  <td className="py-3 px-4 text-muted-foreground">{contact.phone || "-"}</td>
                  <td className="py-3 px-4 text-muted-foreground">
                    {formatTimeAgo(contact.lastContact)}
                  </td>
                  <td className="py-3 px-4">
                    <div className="flex items-center space-x-2">
                      <Button variant="ghost" size="sm" data-testid={`button-call-${contact.id}`}>
                        <Phone className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" data-testid={`button-email-${contact.id}`}>
                        <Mail className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm" data-testid={`button-edit-${contact.id}`}>
                        <Edit className="w-4 h-4" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={6} className="py-8 text-center text-muted-foreground">
                  {searchTerm || roleFilter !== "all" 
                    ? "No contacts match your search criteria" 
                    : "No contacts found for this company"
                  }
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
