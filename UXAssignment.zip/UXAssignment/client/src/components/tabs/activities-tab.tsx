import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Plus, Phone, Mail, Calendar as CalendarIcon, User } from "lucide-react";
import { type Activity } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ActivitiesTabProps {
  companyId: string;
}

export default function ActivitiesTab({ companyId }: ActivitiesTabProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");

  const { data: activities, isLoading } = useQuery<Activity[]>({
    queryKey: ["/api/companies", companyId, "activities"],
  });

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "call":
        return <Phone className="text-blue-600" size={20} />;
      case "email":
        return <Mail className="text-purple-600" size={20} />;
      case "meeting":
        return <CalendarIcon className="text-green-600" size={20} />;
      case "job":
        return <Plus className="text-green-600" size={20} />;
      default:
        return <User className="text-gray-600" size={20} />;
    }
  };

  const getActivityIconBg = (type: string) => {
    switch (type) {
      case "call":
        return "bg-blue-100";
      case "email":
        return "bg-purple-100";
      case "meeting":
        return "bg-green-100";
      case "job":
        return "bg-green-100";
      default:
        return "bg-gray-100";
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - new Date(date).getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffHours / 24);
    
    if (diffHours < 1) return "Just now";
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? "s" : ""} ago`;
    if (diffDays === 1) return "1 day ago";
    return `${diffDays} day${diffDays > 1 ? "s" : ""} ago`;
  };

  const filteredActivities = activities?.filter((activity) => {
    const matchesSearch = activity.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         activity.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         activity.userName?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = typeFilter === "all" || activity.type.toLowerCase() === typeFilter.toLowerCase();
    return matchesSearch && matchesType;
  }) || [];

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="animate-pulse">
          <div className="h-10 bg-muted rounded-lg mb-4"></div>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 bg-muted rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
            <Input
              type="text"
              placeholder="Search activities..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-80"
              data-testid="input-search-activities"
            />
          </div>
          <Select value={typeFilter} onValueChange={setTypeFilter}>
            <SelectTrigger className="w-48" data-testid="select-type-filter">
              <SelectValue placeholder="All Types" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="call">Calls</SelectItem>
              <SelectItem value="email">Emails</SelectItem>
              <SelectItem value="meeting">Meetings</SelectItem>
              <SelectItem value="note">Notes</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button className="bg-primary text-primary-foreground hover:bg-primary/90" data-testid="button-log-activity">
          <Plus className="w-4 h-4 mr-2" />
          Log Activity
        </Button>
      </div>

      <div className="space-y-4">
        {filteredActivities.length > 0 ? (
          filteredActivities.map((activity) => (
            <div key={activity.id} className="bg-card border border-border rounded-lg p-4 hover:shadow-sm transition-shadow" data-testid={`card-activity-${activity.id}`}>
              <div className="flex items-start space-x-4">
                <div className={`w-10 h-10 ${getActivityIconBg(activity.type)} rounded-full flex items-center justify-center flex-shrink-0`}>
                  {getActivityIcon(activity.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium text-foreground">{activity.title}</h4>
                    <span className="text-sm text-muted-foreground">
                      {formatTimeAgo(activity.createdAt!)}
                    </span>
                  </div>
                  {activity.description && (
                    <p className="text-sm text-muted-foreground mb-2">
                      {activity.description}
                    </p>
                  )}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                      {activity.metadata && typeof activity.metadata === 'object' && 'duration' in activity.metadata && (
                        <>
                          <span>Duration: {(activity.metadata as any).duration}</span>
                          <span>•</span>
                        </>
                      )}
                      {activity.metadata && typeof activity.metadata === 'object' && 'subject' in activity.metadata && (
                        <>
                          <span>Subject: {(activity.metadata as any).subject}</span>
                          <span>•</span>
                        </>
                      )}
                      {activity.metadata && typeof activity.metadata === 'object' && 'jobId' in activity.metadata && (
                        <>
                          <span>Job ID: #{(activity.metadata as any).jobId}</span>
                          <span>•</span>
                        </>
                      )}
                      {activity.userName && (
                        <span>By: {activity.userName}</span>
                      )}
                    </div>
                    <Button variant="link" className="text-primary text-sm p-0 h-auto" data-testid={`button-view-details-${activity.id}`}>
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8 text-muted-foreground">
            {searchTerm || typeFilter !== "all" 
              ? "No activities match your search criteria" 
              : "No activities found for this company"
            }
          </div>
        )}
      </div>
    </div>
  );
}
