import { type Company, type Contact, type Job, type Candidate, type Activity, type InsertCompany, type InsertContact, type InsertJob, type InsertCandidate, type InsertActivity } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Company methods
  getCompany(id: string): Promise<Company | undefined>;
  getCompanies(): Promise<Company[]>;
  createCompany(company: InsertCompany): Promise<Company>;
  updateCompany(id: string, company: Partial<InsertCompany>): Promise<Company | undefined>;
  
  // Contact methods
  getContacts(companyId: string): Promise<Contact[]>;
  getContact(id: string): Promise<Contact | undefined>;
  createContact(contact: InsertContact): Promise<Contact>;
  updateContact(id: string, contact: Partial<InsertContact>): Promise<Contact | undefined>;
  
  // Job methods
  getJobs(companyId: string): Promise<Job[]>;
  getJob(id: string): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: string, job: Partial<InsertJob>): Promise<Job | undefined>;
  
  // Candidate methods
  getCandidates(companyId: string): Promise<Candidate[]>;
  getCandidate(id: string): Promise<Candidate | undefined>;
  createCandidate(candidate: InsertCandidate): Promise<Candidate>;
  updateCandidate(id: string, candidate: Partial<InsertCandidate>): Promise<Candidate | undefined>;
  
  // Activity methods
  getActivities(companyId: string): Promise<Activity[]>;
  createActivity(activity: InsertActivity): Promise<Activity>;
}

export class MemStorage implements IStorage {
  private companies: Map<string, Company>;
  private contacts: Map<string, Contact>;
  private jobs: Map<string, Job>;
  private candidates: Map<string, Candidate>;
  private activities: Map<string, Activity>;

  constructor() {
    this.companies = new Map();
    this.contacts = new Map();
    this.jobs = new Map();
    this.candidates = new Map();
    this.activities = new Map();
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Create sample company
    const companyId = randomUUID();
    const company: Company = {
      id: companyId,
      name: "TechCorp Solutions",
      industry: "Technology & Software",
      location: "San Francisco, CA",
      size: "500-1000 employees",
      website: "techcorp.com",
      founded: "2015",
      revenue: "$50M - $100M",
      status: "Active",
      description: "TechCorp Solutions is a leading technology company specializing in cloud infrastructure and enterprise software solutions. We help businesses transform their operations through innovative technology.",
      logoUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      createdAt: new Date(),
    };
    this.companies.set(companyId, company);

    // Create sample contacts
    const contacts: InsertContact[] = [
      {
        companyId,
        name: "John Smith",
        role: "Head of Engineering",
        email: "john.smith@techcorp.com",
        phone: "+1 (555) 123-4567",
        lastContact: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        companyId,
        name: "Emily Martinez",
        role: "HR Director",
        email: "emily.martinez@techcorp.com",
        phone: "+1 (555) 234-5678",
        lastContact: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      },
    ];

    contacts.forEach(contact => {
      const id = randomUUID();
      this.contacts.set(id, { 
        ...contact, 
        id, 
        createdAt: new Date(),
        email: contact.email ?? null,
        role: contact.role ?? null,
        phone: contact.phone ?? null,
        lastContact: contact.lastContact ?? null
      });
    });

    // Create sample jobs
    const jobs: InsertJob[] = [
      {
        companyId,
        title: "Senior Frontend Developer",
        location: "San Francisco, CA",
        type: "Full-time",
        salaryRange: "$120K - $160K",
        status: "Active",
        description: "Looking for an experienced frontend developer to join our growing team. Must have expertise in React, TypeScript, and modern CSS frameworks.",
        requirements: "React, TypeScript, CSS, 5+ years experience",
        applicationCount: 24,
        interviewCount: 8,
      },
      {
        companyId,
        title: "Product Manager",
        location: "Remote",
        type: "Full-time",
        salaryRange: "$140K - $180K",
        status: "Draft",
        description: "Seeking a strategic product manager to lead our core platform initiatives and drive product roadmap execution.",
        requirements: "Product management, strategy, roadmap planning, 3+ years experience",
        applicationCount: 0,
        interviewCount: 0,
      },
    ];

    jobs.forEach(job => {
      const id = randomUUID();
      this.jobs.set(id, { 
        ...job, 
        id, 
        createdAt: new Date(),
        location: job.location ?? null,
        type: job.type ?? null,
        salaryRange: job.salaryRange ?? null,
        description: job.description ?? null,
        requirements: job.requirements ?? null,
        applicationCount: job.applicationCount ?? null,
        interviewCount: job.interviewCount ?? null
      });
    });

    // Create sample candidates
    const candidates: InsertCandidate[] = [
      {
        companyId,
        jobId: Array.from(this.jobs.values())[0].id,
        name: "Alice Davis",
        email: "alice.davis@email.com",
        stage: "Interview",
        appliedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
        lastUpdate: new Date(Date.now() - 2 * 60 * 60 * 1000),
      },
      {
        companyId,
        jobId: Array.from(this.jobs.values())[0].id,
        name: "Bob Wilson",
        email: "bob.wilson@email.com",
        stage: "Offer",
        appliedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        lastUpdate: new Date(Date.now() - 24 * 60 * 60 * 1000),
      },
    ];

    candidates.forEach(candidate => {
      const id = randomUUID();
      this.candidates.set(id, { 
        ...candidate, 
        id, 
        createdAt: new Date(),
        jobId: candidate.jobId ?? null,
        appliedAt: candidate.appliedAt ?? null,
        lastUpdate: candidate.lastUpdate ?? null
      });
    });

    // Create sample activities
    const activities: InsertActivity[] = [
      {
        companyId,
        type: "call",
        title: "Call with John Smith",
        description: "Discussed requirements for the Senior Frontend Developer position. John mentioned they're looking for someone with strong React and TypeScript experience.",
        userId: "user1",
        userName: "Sarah Johnson",
        metadata: { duration: "30 min" },
      },
      {
        companyId,
        type: "job",
        title: "New job posted: Senior Frontend Developer",
        description: "Created and published the Senior Frontend Developer position. Job is now live and accepting applications.",
        userId: "user2",
        userName: "Mike Chen",
        metadata: { jobId: "TCD-2024-001" },
      },
      {
        companyId,
        type: "email",
        title: "Email sent to Emily Martinez",
        description: "Sent follow-up email regarding the Product Manager role requirements and timeline expectations.",
        userId: "user3",
        userName: "Lisa Wang",
        metadata: { subject: "Product Manager Role - Follow Up" },
      },
    ];

    activities.forEach(activity => {
      const id = randomUUID();
      this.activities.set(id, { 
        ...activity, 
        id, 
        createdAt: new Date(),
        description: activity.description ?? null,
        userId: activity.userId ?? null,
        userName: activity.userName ?? null,
        metadata: activity.metadata ?? null
      });
    });
  }

  async getCompany(id: string): Promise<Company | undefined> {
    return this.companies.get(id);
  }

  async getCompanies(): Promise<Company[]> {
    return Array.from(this.companies.values());
  }

  async createCompany(insertCompany: InsertCompany): Promise<Company> {
    const id = randomUUID();
    const company: Company = { 
      ...insertCompany, 
      id, 
      createdAt: new Date(),
      industry: insertCompany.industry ?? null,
      location: insertCompany.location ?? null,
      size: insertCompany.size ?? null,
      website: insertCompany.website ?? null,
      founded: insertCompany.founded ?? null,
      revenue: insertCompany.revenue ?? null,
      description: insertCompany.description ?? null,
      logoUrl: insertCompany.logoUrl ?? null
    };
    this.companies.set(id, company);
    return company;
  }

  async updateCompany(id: string, updates: Partial<InsertCompany>): Promise<Company | undefined> {
    const company = this.companies.get(id);
    if (!company) return undefined;
    
    const updatedCompany = { ...company, ...updates };
    this.companies.set(id, updatedCompany);
    return updatedCompany;
  }

  async getContacts(companyId: string): Promise<Contact[]> {
    return Array.from(this.contacts.values()).filter(contact => contact.companyId === companyId);
  }

  async getContact(id: string): Promise<Contact | undefined> {
    return this.contacts.get(id);
  }

  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = randomUUID();
    const contact: Contact = { 
      ...insertContact, 
      id, 
      createdAt: new Date(),
      email: insertContact.email ?? null,
      role: insertContact.role ?? null,
      phone: insertContact.phone ?? null,
      lastContact: insertContact.lastContact ?? null
    };
    this.contacts.set(id, contact);
    return contact;
  }

  async updateContact(id: string, updates: Partial<InsertContact>): Promise<Contact | undefined> {
    const contact = this.contacts.get(id);
    if (!contact) return undefined;
    
    const updatedContact = { ...contact, ...updates };
    this.contacts.set(id, updatedContact);
    return updatedContact;
  }

  async getJobs(companyId: string): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter(job => job.companyId === companyId);
  }

  async getJob(id: string): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = randomUUID();
    const job: Job = { 
      ...insertJob, 
      id, 
      createdAt: new Date(),
      location: insertJob.location ?? null,
      type: insertJob.type ?? null,
      salaryRange: insertJob.salaryRange ?? null,
      description: insertJob.description ?? null,
      requirements: insertJob.requirements ?? null,
      applicationCount: insertJob.applicationCount ?? null,
      interviewCount: insertJob.interviewCount ?? null
    };
    this.jobs.set(id, job);
    return job;
  }

  async updateJob(id: string, updates: Partial<InsertJob>): Promise<Job | undefined> {
    const job = this.jobs.get(id);
    if (!job) return undefined;
    
    const updatedJob = { ...job, ...updates };
    this.jobs.set(id, updatedJob);
    return updatedJob;
  }

  async getCandidates(companyId: string): Promise<Candidate[]> {
    return Array.from(this.candidates.values()).filter(candidate => candidate.companyId === companyId);
  }

  async getCandidate(id: string): Promise<Candidate | undefined> {
    return this.candidates.get(id);
  }

  async createCandidate(insertCandidate: InsertCandidate): Promise<Candidate> {
    const id = randomUUID();
    const candidate: Candidate = { 
      ...insertCandidate, 
      id, 
      createdAt: new Date(),
      jobId: insertCandidate.jobId ?? null,
      appliedAt: insertCandidate.appliedAt ?? null,
      lastUpdate: insertCandidate.lastUpdate ?? null
    };
    this.candidates.set(id, candidate);
    return candidate;
  }

  async updateCandidate(id: string, updates: Partial<InsertCandidate>): Promise<Candidate | undefined> {
    const candidate = this.candidates.get(id);
    if (!candidate) return undefined;
    
    const updatedCandidate = { ...candidate, ...updates };
    this.candidates.set(id, updatedCandidate);
    return updatedCandidate;
  }

  async getActivities(companyId: string): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .filter(activity => activity.companyId === companyId)
      .sort((a, b) => new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime());
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = randomUUID();
    const activity: Activity = { 
      ...insertActivity, 
      id, 
      createdAt: new Date(),
      description: insertActivity.description ?? null,
      userId: insertActivity.userId ?? null,
      userName: insertActivity.userName ?? null,
      metadata: insertActivity.metadata ?? null
    };
    this.activities.set(id, activity);
    return activity;
  }
}

export const storage = new MemStorage();
